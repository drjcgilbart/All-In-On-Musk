# Florida Tesla Fleet & Robotaxi Model v1.1

This workbook is an experimental 5-year Orlando / Florida model of a business that provides fleet services and owns a Tesla fleet. Driven Model Ys come first. Cybercab robotaxis are added from Year 3.

Home: https://www.allinonmusk.com

## What's inside

- Cover
- Dashboard
- Assumptions
- Revenue
- Operating Expenses
- Capital and Financing
- Robotaxi Transition
- Scenarios
- Notes
- Glossary

## How to use

Edit the blue cells on Assumptions. Watch Dashboard.

## Honesty

On the base-case assumptions, Year 1 EBITDA is negative on purpose.

## Not advice

This is not financial, tax, or investment advice. It is not affiliated with Tesla. The Notes sheet has the full caveats, including the network-fee placeholder.
